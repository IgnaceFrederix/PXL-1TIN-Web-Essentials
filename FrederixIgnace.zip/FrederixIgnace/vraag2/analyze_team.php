<?php
$aantal =
if ($aantal >=5){

    if ($_GET['teamname'] =""){
        echo "Error no name was supplied";
    }else{

        if ($_GET['getal']=""){
            echo "Error no members were supplied";
        }
    }

}else{
    echo "Error input data array is way tpp small";
}

?>