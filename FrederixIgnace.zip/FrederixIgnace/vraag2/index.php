<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css" />

    <meta charset="UTF-8">
    <title>Platform eXtreme Leadership</title>
</head>
<body>
<h1>Counter Terrorism Team Planner</h1>
<h3>Terrorism is a significant threat to peace and security, prosperity and people.</h3>

<form method="get">


<?php
for($i = 1; $i <=  10; $i++) {
    echo    "<a  name=getal href='create_team.php'>Create a team Consisting out of $i members</a>";
    echo "<br>";

}
?>
</form>
</body>
</html>
