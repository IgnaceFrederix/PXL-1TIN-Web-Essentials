<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css" />

    <meta charset="UTF-8">
    <title>Platform eXtreme Leadership</title>
</head>
<body>
<?php
echo $_GET['getal'];
$message = "Error: you can't create a team without providing the number of members. ";
    $number_of_members = 5;
if ($number_of_members < 1 ||  $number_of_members > 12  || $number_of_members =number_format()){
    echo $message;
   echo  "<title>unable to create team!</title>";

}else {
    if ($number_of_members == 1) {
        echo "<title>Create a team with .$number_of_members. member </title>";

    } else {
        echo "<title>Create a team with .$number_of_members. members </title>";

    }
}
    ?>

     <h1>Team and Game Value</h1>
<form method="get" action="analyze_team.php">
    <fieldset>
    <legend>Team Information</legend>
        <label for="teamname">Team name:</label>
        <input maxlength="18" type="text" id="teamname" name ="teamname"/>
    </fieldset>

    <fieldset>
    <legend>Members</legend>
    <?php
    $number_of_members = 5;
    for($i = 1; $i <=  $number_of_members; $i++) {
        echo "<fieldset class='fieldsetgen'>";
        echo "<legend>Members $i</legend>";
        echo " <label for='class$i'>Member $i</label>";
        echo "<select  name='class$i'>
            <option value='1'>breacher</option>
            <option value='2'>Leader</option>
            <option value='3''>Assaulter</option>
            <option value='3''>Sniper</option>
        </select>";
        echo " <label for='weapon$i'>Weapon $i</label>";

        echo "<select  name='weapon$i'>
            <option value='1'>mini door ram</option>
            <option value='2'>MP5</option>
            <option value='3''>AR15</option>
            <option value='3''>M24</option>
            <option value='3''>SWS</option>
        </select>";
        echo "</fieldset>";



    }
    ?>
    </fieldset>
<fieldset>
        <legend>Operation Information</legend>
        <label for="enemy">Number of Opponents</label>
<input maxlength="18" type="number" id="enemy" name ="enemy"/>
</fieldset>
<input type="hidden" name="hiddengetal" id="hiddengetal" value="<?php echo $_GET['getal'];  ?>" />
<input type="submit" id="knop" name="analyze" value="Analyze team" />
</form>
</body>
</html>

